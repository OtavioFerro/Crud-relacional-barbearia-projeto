<?php

$nome     = $_POST['nome'];
$idade    = $_POST['idade'];
$cpf      = $_POST['cpf'];
$endereco = $_POST['endereco'];
$idfuncao = $_POST['idfuncao'];

$servidor = 'localhost';
$usuario  = 'root';
$senha    = 'Home@spSENAI2025!';
$banco    = 'sistema_db';

$conexao = new mysqli($servidor, $usuario, $senha, $banco);

if ($conexao->connect_error) {
    die('Falha na conexão: ' . $conexao->connect_error);
}

// Utilização de Prepared Statement para segurança e inserção da FK idfuncao
$stmt = $conexao->prepare("INSERT INTO clientes (nome, idade, cpf, endereco, idfuncao) VALUES (?, ?, ?, ?, ?)");
$stmt->bind_param("sissi", $nome, $idade, $cpf, $endereco, $idfuncao);

if ($stmt->execute()) {
    echo "<h2>Cliente cadastrado com sucesso!</h2>";
    echo "<p>Dados registrados:</p>";
    echo "Nome: " . htmlspecialchars($nome) . "<br>";
    echo "Idade: " . htmlspecialchars($idade) . " anos<br>";
    echo "CPF: " . htmlspecialchars($cpf) . "<br>";
    echo "Endereço: " . htmlspecialchars($endereco) . "<br>";
    echo "ID Função: " . htmlspecialchars($idfuncao) . "<br>";
} else {
    echo "Erro ao cadastrar: " . $stmt->error;
}

$stmt->close();
$conexao->close();
?>