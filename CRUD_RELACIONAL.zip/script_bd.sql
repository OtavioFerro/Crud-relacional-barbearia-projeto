-- 1. Criação do Banco de Dados (caso ainda não exista)
DROP DATABASE IF EXISTS sistema_db;
CREATE DATABASE IF NOT EXISTS sistema_db;
USE sistema_db;

-- 2. Criação da tabela de Funções (Tabela Pai)
CREATE TABLE IF NOT EXISTS funcoes (
    idfuncao INT AUTO_INCREMENT PRIMARY KEY,
    nome_funcao VARCHAR(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 3. Criação da tabela de Clientes (Tabela Filho com a FK idfuncao)
CREATE TABLE IF NOT EXISTS clientes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    idade INT NOT NULL,
    cpf VARCHAR(14) NOT NULL,
    endereco VARCHAR(255) NOT NULL,
    idfuncao INT NOT NULL,
    CONSTRAINT fk_cliente_funcao FOREIGN KEY (idfuncao) 
        REFERENCES funcoes(idfuncao) 
        ON DELETE RESTRICT 
        ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 4. Inserção de dados iniciais na tabela de Funções para popular o <select>
INSERT INTO funcoes (nome_funcao) VALUES 
('Administrador'),
('Gerente'),
('Atendente'),
('Desenvolvedor'),
('Analista de Suporte');