<?php
// Função para listar as funções do banco de dados e montar o <select>
function listarFuncoes() {
    $servidor = 'localhost';
    $usuario = 'root';
    $senha = 'Home@spSENAI2025!';
    $banco = 'sistema_db';
    $conexao = new mysqli($servidor, $usuario, $senha, $banco);
    if ($conexao->connect_error) {
        return "<option value=''>Erro ao carregar funções</option>";
    }
    $sql = "SELECT idfuncao, nome_funcao FROM funcoes";
    $resultado = $conexao->query($sql);
    $options = "";
    if ($resultado && $resultado->num_rows > 0) {
        while ($linha = $resultado->fetch_assoc()) {
            $options .= "<option value='" . $linha['idfuncao'] . "'>" . $linha['nome_funcao'] . "</option>";
        }
    } else {
        $options = "<option value=''>Nenhuma função cadastrada</option>";
    }
    $conexao->close();
    return $options;
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <title>Cadastro de Cliente</title>
</head>
<body>

  <h2>Cadastro de Cliente</h2>

  <form action="cadastro.php" method="POST">

    <label for="nome">Nome:</label>
    <input type="text" id="nome" name="nome" required>
    <p>

    <label for="idade">Idade:</label>
    <input type="number" id="idade" name="idade" required>
    <p>

    <label for="cpf">CPF:</label>
    <input type="text" id="cpf" name="cpf" required>
    <p>
    <label for="endereco">Endereço:</label>
    <input type="text" id="endereco" name="endereco" required>
    <p>
    <label for="idfuncao">Função:</label>
    <select id="idfuncao" name="idfuncao" required>
      <option value="">Selecione uma função</option>
      <?php echo listarFuncoes(); ?>
    </select>
    <p>
    <button type="submit">Cadastrar Cliente</button>

  </form>
</body>
</html>